<?php
define('DB_HOST',       'localhost');
define('DB_USER',       'root');
define('DB_PASS',       base64_decode('Z2F0dmVyZWVuem9tYmll'));
define('DB_NAME',       'various');
