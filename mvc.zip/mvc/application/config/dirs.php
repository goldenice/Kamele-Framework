<?php
define('SYSTEM',        'system/');
define('CONTROLLERS',   'application/controllers/');
define('MODELS',        'application/models/');
define('VIEWS',         'application/views/');
define('RESOURCES',     'application/resources/');