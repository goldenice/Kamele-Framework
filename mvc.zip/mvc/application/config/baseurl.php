<?php
define('BASEURL', 'https://rpi.ricklubbers.nl/dev/technasium/0.6/');